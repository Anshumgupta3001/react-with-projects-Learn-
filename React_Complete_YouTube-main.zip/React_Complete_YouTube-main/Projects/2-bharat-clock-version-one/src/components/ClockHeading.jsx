let ClockHeading = () => {
  return <h1 className="fw-bolder">Bharat Clock</h1>;
};

export default ClockHeading;
