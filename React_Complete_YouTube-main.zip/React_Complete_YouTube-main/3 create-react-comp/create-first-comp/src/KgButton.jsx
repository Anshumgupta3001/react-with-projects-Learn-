export function KgButton() {
  return <button>Like this Video</button>
}